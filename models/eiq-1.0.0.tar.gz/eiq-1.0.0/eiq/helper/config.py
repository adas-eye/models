# Copyright 2020 NXP Semiconductors
# SPDX-License-Identifier: BSD-3-Clause

INFERENCE_TIME_MESSAGE = "INFERENCE TIME: "
